# Geek_lab_3_pb
Laboratorio 3: Manejo de estructuras condicionales

# Sistema de Parqueadero Geek
Crear un sistema de información que permita ingresar los datos básicos de un vehículo y el tiempo del servicio. Si el vehículo es un carro se dará un 10% descuento, si el vehículo es una moto el descuento será del 15%. El sistema permitirá ingresar el propietario, la placa, el modelo, fecha, hora inicio y cantidad de horas de parqueo. <br/>
El pago por horas es el siguiente: <br/>
-	Las dos primeras horas a 5.000 c/u.
-	Las siguientes tres a 4.000 c/u.
-	Las cinco siguientes a 3.000 c/u.
-	Después de diez horas el costo por cada hora es de 2000 pesos.<br/><br/>
Imprimir toda la información de la factura del cliente, el descuento y el total a pagar.<br/>
Realizar una bitácora con las etiquetas HTML (mínimo 20).<br/>
Realizar una bitácora con los estilos CSS (mínimo 20).<br/>
La información debe estar en el repositorio y agregar la URL del proyecto en un archivo de Excel, en la carpeta de evidencia laboratorios.


